-- Open in Script Editor and click Run once. No administrator password needed.
set helperText to "-- NFL Crew Mac helper. Downloads public NFL scores only; no workbook data is sent.
on ready(ignored)
    set libraryPath to POSIX path of (path to library folder from user domain)
    set cachePath to libraryPath & \"Containers/com.microsoft.Excel/Data/Library/Caches/NFLCrewLogos_v3/\"
    do shell script \"/bin/mkdir -p \" & quoted form of cachePath
    return cachePath
end ready

on fetchScores(periodText)
    set periodNumber to periodText as integer
    if periodNumber < 1 or periodNumber > 22 then error \"Invalid NFL period.\"
    set seasonType to 2
    set feedWeek to periodNumber
    if periodNumber > 18 then
        set seasonType to 3
        set feedWeek to item (periodNumber - 18) of {1, 2, 3, 5}
    end if
    set feedURL to \"https://site.api.espn.com/apis/site/v2/sports/football/nfl/scoreboard?dates=2026&seasontype=\" & seasonType & \"&week=\" & feedWeek & \"&limit=100\"
    return do shell script \"/usr/bin/curl --fail --silent --show-error --connect-timeout 5 --max-time 15 \" & quoted form of feedURL
end fetchScores
"
set libraryPath to POSIX path of (path to library folder from user domain)
set targetFolder to libraryPath & "Application Scripts/com.microsoft.Excel/"
do shell script "/bin/mkdir -p " & quoted form of targetFolder
set targetFile to POSIX file (targetFolder & "CrewMacBridge.applescript")
set outputFile to open for access targetFile with write permission
try
    set eof outputFile to 0
    write helperText to outputFile as «class utf8»
    close access outputFile
on error errorMessage number errorNumber
    try
        close access outputFile
    end try
    error errorMessage number errorNumber
end try
display dialog "NFL Crew helper is installed. Open NFL-Crew-Mac.xlsm in Excel and enable macros. Scores will check when it opens; Refresh Scores checks again." buttons {"OK"} default button "OK"
