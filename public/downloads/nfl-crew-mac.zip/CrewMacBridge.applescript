-- NFL Crew Mac helper. Downloads public NFL scores only; no workbook data is sent.
on ready(ignored)
    set libraryPath to POSIX path of (path to library folder from user domain)
    set cachePath to libraryPath & "Containers/com.microsoft.Excel/Data/Library/Caches/NFLCrewLogos_v3/"
    do shell script "/bin/mkdir -p " & quoted form of cachePath
    return cachePath
end ready

on fetchScores(periodText)
    set periodNumber to periodText as integer
    if periodNumber < 1 or periodNumber > 22 then error "Invalid NFL period."
    set seasonType to 2
    set feedWeek to periodNumber
    if periodNumber > 18 then
        set seasonType to 3
        set feedWeek to item (periodNumber - 18) of {1, 2, 3, 5}
    end if
    set feedURL to "https://site.api.espn.com/apis/site/v2/sports/football/nfl/scoreboard?dates=2026&seasontype=" & seasonType & "&week=" & feedWeek & "&limit=100"
    return do shell script "/usr/bin/curl --fail --silent --show-error --connect-timeout 5 --max-time 15 " & quoted form of feedURL
end fetchScores
